var Vlinha1 = "|12.123.456/0001-01 |Ronaldo Pereira Ltda.|";
var Vlinha2 = "|13.456.789/0002-02 |Igor U. Fernandes Ltda.|";
var Vlinha3 = "|14.567.891/0003-03 |Pedro S. Machado Ltda.|";
var Vlinha4 = "|15.678.987/0004-09 |Rafael B. da Silva Ltda.|";
var Vlinha5 = "|16.625.897/0005-09 |Rafael E. da Silva Ltda.|";
var Vlinha6 = "|03.234.569/0006-22 |Vitor H. dos Santos Ltda.|";
var Vlinha7 = "|23.132.598/0001-01 |Wesley de Souza P. Ltda.|";
var Vlinha8 = "|09.756.332/0001-15 |Wilson V. Galdino Ltda.|";

const Vdata1 =  "10/11/2024";
const Vdata2  = "02/12/2024";
const Vdata3  = "31/12/2024";
const Vdata4  = "15/01/2025";
const Vdata5  = "15/02/2025";
const Vdata6  = "03/12/2024";
const Vdata7  = "04/12/2024";
const Vdata8  = "05/12/2024";

const d1c = moment(Vdata1, "DD/MM/YYYY");
const d2c = moment(Vdata2, "DD/MM/YYYY");
const d3c = moment(Vdata3, "DD/MM/YYYY");
const d4c = moment(Vdata4, "DD/MM/YYYY");
const d5c = moment(Vdata5, "DD/MM/YYYY");
const d6c = moment(Vdata6, "DD/MM/YYYY");
const d7c = moment(Vdata7, "DD/MM/YYYY");
const d8c = moment(Vdata8, "DD/MM/YYYY");





